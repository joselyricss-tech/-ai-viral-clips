# AI Viral Clips

Starter project for a Spanish-language platform that helps creators turn authorized YouTube videos and livestream recordings into short vertical clips.

## Estado actual
Este paquete contiene una primera base funcional de interfaz y API:
- Dashboard web en Next.js.
- API inicial en FastAPI.
- Validación básica de enlaces de YouTube.
- Estructura preparada para añadir análisis, subtítulos y exportación.

**Importante:** todavía no descarga ni procesa videos, no detecta momentos automáticamente y no publica clips. Esas funciones requieren integrar servicios de procesamiento y respetar los permisos, derechos de autor y condiciones de YouTube. Úsalo solo con contenido propio o autorizado.

## Requisitos
- Node.js 20 o superior
- Python 3.10 o superior

## 1. Iniciar el backend
Abre una terminal dentro de `backend`:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

API: http://127.0.0.1:8000  
Documentación: http://127.0.0.1:8000/docs

## 2. Iniciar la web
Abre otra terminal dentro de la carpeta principal:

```bash
npm install
npm run dev
```

Web: http://localhost:3000

## 3. Subir a GitHub desde el navegador
1. Descarga y descomprime `ai-viral-clips.zip`.
2. Abre https://github.com/joselyricss-tech/-ai-viral-clips
3. Pulsa **Add file** → **Upload files**.
4. Abre la carpeta descomprimida y selecciona todos sus archivos y carpetas. En móvil, puede ser más sencillo hacerlo desde una computadora.
5. Espera a que terminen de cargarse.
6. En **Commit changes**, escribe `Agregar estructura inicial de AI Viral Clips`.
7. Pulsa **Commit changes**.

No subas archivos `.env`, contraseñas, claves API ni carpetas `node_modules` o `.venv`.

## Próximas etapas
1. Autenticación y almacenamiento de proyectos.
2. Integración legal/autorizada de fuentes de video.
3. Transcripción y detección de momentos destacados.
4. Recorte vertical 9:16 y subtítulos.
5. Exportación y biblioteca de clips.
