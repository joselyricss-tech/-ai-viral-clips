import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Viral Clips",
  description: "Convierte contenido autorizado en clips verticales.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
