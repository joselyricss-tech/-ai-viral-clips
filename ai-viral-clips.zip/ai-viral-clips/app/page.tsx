"use client";

import { useState } from "react";

export default function Home() {
  const [source, setSource] = useState("video");
  const [url, setUrl] = useState("");
  const [message, setMessage] = useState("");

  async function submitProject() {
    setMessage("Enviando solicitud...");
    try {
      const base = process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000";
      const response = await fetch(`${base}/api/projects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source_type: source, youtube_url: url }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "No se pudo registrar el proyecto.");
      setMessage(`Proyecto registrado: ${data.project_id}. ${data.message}`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Error de conexión con la API.");
    }
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">✦</span><span>AI Viral Clips</span></div>
        <p className="side-label">MENÚ PRINCIPAL</p>
        <a className="nav active">▦　Panel principal</a>
        <a className="nav">▣　Mis proyectos</a>
        <a className="nav">▶　Biblioteca de clips</a>
        <a className="nav">⚙　Configuración</a>
        <div className="sidebar-note">Tu contenido. Tus mejores momentos.</div>
      </aside>

      <section className="content">
        <header className="topbar">
          <div><p className="eyebrow">CENTRO DE CREACIÓN</p><h1>Panel principal</h1></div>
          <div className="avatar">AV</div>
        </header>

        <section className="welcome">
          <div>
            <p className="eyebrow light">AI VIRAL CLIPS</p>
            <h2>Convierte tus videos en<br />momentos que se hacen virales.</h2>
            <p>Prepara clips verticales para TikTok, Reels y YouTube Shorts.</p>
          </div>
          <div className="orb">✦</div>
        </section>

        <div className="section-heading"><div><p className="eyebrow">EMPEZAR</p><h2>Crear un proyecto</h2></div><span className="status">● Sistema inicial</span></div>
        <section className="project-card">
          <label className="field-label">¿Qué contenido quieres analizar?</label>
          <div className="choice-row">
            <button className={source === "video" ? "choice selected" : "choice"} onClick={() => setSource("video")}>▶　Video publicado</button>
            <button className={source === "live" ? "choice selected" : "choice"} onClick={() => setSource("live")}>◉　Transmisión en vivo</button>
          </div>
          <label className="field-label" htmlFor="youtube">Enlace de YouTube</label>
          <input id="youtube" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." />
          <button className="primary" onClick={submitProject} disabled={!url.trim()}>＋　Registrar proyecto</button>
          {message && <p className="message">{message}</p>}
          <p className="hint">Usa únicamente videos o transmisiones que sean tuyos o para los que tengas autorización.</p>
        </section>

        <div className="section-heading"><div><p className="eyebrow">RESUMEN</p><h2>Tu espacio de trabajo</h2></div></div>
        <div className="stats">
          <article className="stat"><span>Proyectos</span><strong>0</strong><small>Registrados</small></article>
          <article className="stat"><span>Clips creados</span><strong>0</strong><small>Listos para revisar</small></article>
          <article className="stat"><span>Minutos analizados</span><strong>0</strong><small>Tiempo procesado</small></article>
        </div>
        <section className="empty"><div className="empty-icon">▤</div><h3>Tu biblioteca está esperando</h3><p>Cuando registres proyectos y se integre el procesamiento, tus clips aparecerán aquí.</p></section>
        <footer>AI Viral Clips · Versión inicial de desarrollo</footer>
      </section>
    </main>
  );
}
