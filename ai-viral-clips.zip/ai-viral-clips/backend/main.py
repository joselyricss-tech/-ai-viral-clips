from datetime import datetime, timezone
from uuid import uuid4
from urllib.parse import urlparse, parse_qs
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl

app = FastAPI(title="AI Viral Clips API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ProjectRequest(BaseModel):
    source_type: str
    youtube_url: HttpUrl

def is_youtube_url(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host == "youtube.com" or host.endswith(".youtube.com") or host == "youtu.be"

@app.get("/health")
def health():
    return {"status": "ok", "service": "AI Viral Clips API"}

@app.post("/api/projects")
def create_project(payload: ProjectRequest):
    if payload.source_type not in {"video", "live"}:
        raise HTTPException(status_code=400, detail="El tipo debe ser video o live.")
    url = str(payload.youtube_url)
    if not is_youtube_url(url):
        raise HTTPException(status_code=400, detail="Introduce un enlace válido de YouTube.")
    return {
        "project_id": str(uuid4())[:8],
        "source_type": payload.source_type,
        "youtube_url": url,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "registered",
        "message": "Solicitud registrada. El análisis automático todavía no está integrado."
    }
